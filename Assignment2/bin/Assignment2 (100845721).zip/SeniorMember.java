/**
   *
   * @author Rolf-Jaden Sibal
   *
*/

public class SeniorMember extends Member{    
   private double fee;

   public SeniorMember(String name, String address, double fee) {        
        super(name, address);
        this.fee = fee;
   }

   public double getFee() {
        return fee;
   }

    public boolean isSeniorMember() {
         return true;
   }
}